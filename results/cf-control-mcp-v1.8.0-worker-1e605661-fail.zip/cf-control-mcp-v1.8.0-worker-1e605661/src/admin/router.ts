/**
 * v1.8 Admin Console — router.
 * Owner-only auth (session cookie signed with MCP_AUTH_TOKEN). Never
 * protected only by GATEWAY_AUTH_TOKEN. Called for any /admin* path.
 */
import type { AdminEnv, ModelRow, ProviderRow, RoutingRuleRow } from "./types";
import { createSessionCookie, clearSessionCookie, isAuthenticated, verifyOwnerToken } from "./auth";
import { adminLoadingHtml, adminLoginHtml, adminPageHtml, htmlHeaders, pageForPath } from "./ui/approved/pages";
import { getAdminUsageSummary } from "./usage-ext";
import { getAdminSettingsSummary } from "./settings-ext";
import { queryAuditEvents } from "./audit-ext";
import {
	listProviders,
	createProvider,
	createModel,
	updateProviderMetadata,
	moveProviderPriority,
	setProviderEnabled,
	setModelEnabled,
	recordHealthResult,
	logAudit,
	recentAudit,
	getProvider,
	getModel,
	setProviderAlias,
	listModels,
	listRoutingRules,
	listRecentHealthChecks,
	deleteProviderLocalState,
} from "./db";
import { providerHealthFreshness, testProviderConnection } from "./health";
import { setProviderCredential, deleteProviderCredential } from "./credentials";
import { KNOWN_PROVIDER_TEMPLATES, knownProviderTemplate, isProviderAuthType } from "./provider-catalog";
import { createCloudflareCustomProvider, deleteCloudflareCustomProvider, normalizeCustomProviderSlug, validateCustomProviderBaseUrl } from "./custom-providers";
import { checkAdminSameOrigin, isAdminMutationMethod } from "./request-security";
import { providerCallability, providerRuntimeReadiness } from "../provider-gateway/provider-callability";
import { beginProviderOperation, latestProviderOperations, updateProviderOperation } from "./lifecycle";
import { consumeRateLimit } from "../rate-limit";

function json(data: unknown, status = 200): Response {
	return new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json" } });
}

async function readJsonObject(request: Request): Promise<Record<string, unknown> | null> {
	try {
		const value = await request.json<unknown>();
		if (!value || typeof value !== "object" || Array.isArray(value)) return null;
		return value as Record<string, unknown>;
	} catch {
		return null;
	}
}

export interface AdminToolCatalogEntry {
	name: string;
	description: string;
	inputSchema: Record<string, unknown>;
	annotations?: {
		readOnlyHint?: boolean;
		destructiveHint?: boolean;
		idempotentHint?: boolean;
		openWorldHint?: boolean;
	};
}

function aliasesForModel(rules: RoutingRuleRow[], modelId: string): string[] {
	return rules.filter((r) => r.model_id === modelId).map((r) => r.public_alias).sort();
}

function stringField(body: Record<string, unknown>, key: string): string | null {
	const value = body[key];
	return typeof value === "string" && value.trim() ? value.trim() : null;
}


export async function handleAdmin(
	request: Request,
	env: AdminEnv,
	toolCatalog: readonly AdminToolCatalogEntry[] = [],
): Promise<Response> {
	const url = new URL(request.url);
	const path = url.pathname;

	// Admin authentication uses cookies, so state-changing browser requests
	// require an explicit same-origin signal. This guard covers login/logout as
	// well as every /admin/api mutation and fails closed when both Origin and
	// Referer are absent. GET/read-only routes are unaffected.
	if (isAdminMutationMethod(request.method)) {
		const sameOrigin = checkAdminSameOrigin(request);
		if (!sameOrigin.ok) {
			if (path.startsWith("/admin/api") || request.headers.get("Accept")?.includes("application/json")) {
				return json({ ok: false, error: "cross_origin_request_rejected", source: sameOrigin.source }, 403);
			}
			return new Response("Forbidden", { status: 403, headers: { "Cache-Control": "private, no-store" } });
		}
	}

	if ((path === "/admin/" || path === "/admin/index.html") && request.method === "GET") {
		return new Response(null, { status: 308, headers: { Location: "/admin", "Cache-Control": "private, no-store" } });
	}

	if (path === "/admin/login" && request.method === "POST") {
		let token = "";
		const contentType = request.headers.get("Content-Type") || "";
		const acceptHeader = request.headers.get("Accept") || "";
		const isJsonRequest = contentType.includes("application/json") || acceptHeader.includes("application/json");

		if (contentType.includes("application/json")) {
			try {
				const body = (await request.json()) as Record<string, unknown>;
				token = String(body.token || body.password || body.secret || "");
			} catch {}
		} else {
			try {
				const form = await request.formData();
				token = String(form.get("token") || form.get("password") || form.get("secret") || "");
			} catch {}
		}

		if (!token || !(await verifyOwnerToken(token, env))) {
			if (isJsonRequest) {
				return json({ ok: false, error: "Invalid token or secret" }, 401);
			}
			return new Response(adminLoginHtml(), { status: 401, headers: htmlHeaders() });
		}

		const cookie = await createSessionCookie(env);
		await logAudit(env, "admin.login", null, null);

		if (isJsonRequest) {
			return new Response(JSON.stringify({ ok: true, redirect: "/admin" }), {
				status: 200,
				headers: {
					"Content-Type": "application/json",
					"Set-Cookie": cookie,
					"Cache-Control": "private, no-store",
				},
			});
		}

		return new Response(null, { status: 302, headers: { Location: "/admin", "Set-Cookie": cookie } });
	}

	if (path === "/admin/logout" && request.method === "POST") {
		return new Response(null, { status: 302, headers: { Location: "/admin/login", "Set-Cookie": clearSessionCookie() } });
	}

	const authed = await isAuthenticated(request, env);

	if (path === "/admin/api/prelogin" && request.method === "GET") {
		// Public, deliberately minimal pre-login probe. It exposes no secrets or
		// operational state; it only reports the result of the real signed-session
		// check already performed above so the Loading experience can make a
		// truthful decision about whether to prepare Login or bootstrap Admin.
		return new Response(JSON.stringify({ ok: true, authenticated: authed }), {
			status: 200,
			headers: {
				"Content-Type": "application/json",
				"Cache-Control": "private, no-store",
				"Vary": "Cookie",
			},
		});
	}

	if (path === "/admin/login" && request.method === "GET") {
		if (authed) return new Response(null, { status: 302, headers: { Location: "/admin" } });
		// All normal entry paths pass through the approved Loading experience.
		// `ready=1` is an internal visual handoff marker only; it does not bypass
		// authentication and POST /admin/login remains the sole sign-in contract.
		if (url.searchParams.get("ready") !== "1") {
			return new Response(adminLoadingHtml(), { headers: htmlHeaders() });
		}
		return new Response(adminLoginHtml(), { headers: htmlHeaders() });
	}

	if (path === "/admin/loading" && request.method === "GET") {
		return new Response(adminLoadingHtml(), { headers: htmlHeaders() });
	}

	if (!authed) {
		if (path === "/admin" && request.method === "GET") {
			return new Response(adminLoadingHtml(), { headers: htmlHeaders() });
		}
		if (!path.startsWith("/admin/api")) {
			return new Response(null, { status: 302, headers: { Location: "/admin/login" } });
		}
		return json({ ok: false, error: "unauthorized" }, 401);
	}

	// Authenticated Admin console: one approved document per route.
	if (request.method === "GET" && !path.startsWith("/admin/api")) {
		const page = pageForPath(path);
		if (page) return new Response(adminPageHtml(page), { headers: htmlHeaders() });
		return new Response(null, { status: 302, headers: { Location: "/admin" } });
	}


	if (path === "/admin/api/overview" && request.method === "GET") {
		const [providers, models, rules] = await Promise.all([
			listProviders(env),
			listModels(env),
			listRoutingRules(env),
		]);
		const providersById = new Map(providers.map((p) => [p.id, p]));
		const modelsById = new Map(models.map((m) => [m.id, m]));
		const activeRoutes = rules.filter((rule) => {
			const model = modelsById.get(rule.model_id);
			const provider = model ? providersById.get(model.provider_id) : undefined;
			return Boolean(model && provider && providerCallability(provider, model, env).callable);
		}).length;
		const availableModels = models.filter((model) => {
			const provider = providersById.get(model.provider_id);
			return Boolean(provider && providerCallability(provider, model, env).callable);
		}).length;
		return json({
			providerCount: providers.length,
			enabledProviderCount: providers.filter((p) => p.enabled === 1).length,
			healthyCount: providers.filter((p) => p.health_state === "HEALTHY").length,
			modelCount: models.length,
			enabledModelCount: models.filter((m) => m.enabled === 1).length,
			availableModelCount: availableModels,
			disabledModelCount: models.filter((m) => m.enabled !== 1).length,
			routingRuleCount: rules.length,
			activeRoutingAliasCount: activeRoutes,
			unavailableRoutingAliasCount: rules.length - activeRoutes,
			activeRoutingCount: activeRoutes,
			unavailableRoutingCount: rules.length - activeRoutes,
		});
	}

	if (path === "/admin/api/provider-catalog" && request.method === "GET") {
		return json({
			providers: KNOWN_PROVIDER_TEMPLATES.map(({ id, displayName, providerSlug, transport, authType, allowedAuthTypes, credentialRequired, testModel, description, customizable }) => ({
				id, displayName, providerSlug, transport, authType, allowedAuthTypes, credentialRequired, testModel: testModel ?? null, description, customizable: customizable === true,
			})),
			authTypes: ["byok", "cloudflare-unified", "cloudflare-binding", "none"],
		});
	}

	if (path === "/admin/api/providers" && request.method === "POST") {
		const body = await readJsonObject(request);
		if (!body) return json({ ok: false, error: "invalid_json" }, 400);
		const templateId = stringField(body, "templateId") || "custom";
		const template = knownProviderTemplate(templateId);
		if (!template) return json({ ok: false, error: "unknown_provider_template" }, 400);
		const requestedAuth = stringField(body, "authType") || template.authType;
		if (!isProviderAuthType(requestedAuth)) return json({ ok: false, error: "invalid_auth_type" }, 400);
		if (!template.allowedAuthTypes.includes(requestedAuth)) return json({ ok: false, error: "auth_type_not_supported_by_provider", allowedAuthTypes: template.allowedAuthTypes }, 400);

		let id = stringField(body, "id") || template.id;
		let displayName = stringField(body, "displayName") || template.displayName;
		let providerSlug = template.providerSlug;
		let transport = template.transport;
		let baseUrl: string | null = template.baseUrl || null;
		let apiPath: string | null = stringField(body, "apiPath") || template.apiPath || null;
		let customProviderId: string | null = null;
		let provisionedExternalId: string | null = null;
		let operationId: string | null = null;

		try {
			let customSlug: string | null = null;
			if (template.customizable) {
				customSlug = normalizeCustomProviderSlug(stringField(body, "providerSlug") || (template.id === "custom" ? id : template.id));
				if (template.id === "custom") id = `custom-${customSlug}`;
				displayName = stringField(body, "displayName") || template.displayName || customSlug;
				baseUrl = validateCustomProviderBaseUrl(stringField(body, "baseUrl") || template.baseUrl || "");
				apiPath = apiPath || "v1/chat/completions";
				const modelIdForCustom = stringField(body, "modelId") || stringField(body, "testModel") || template.testModel;
				if (!modelIdForCustom) throw new Error("custom_provider_model_required");
			}

			const existing = await getProvider(env, id);
			if (!existing && !template.customizable) {
				operationId = await beginProviderOperation(env, "create", id, "persist_provider");
				await updateProviderOperation(env, operationId, { step: "persist_provider", state: "IN_PROGRESS" });
			}
			if (template.customizable && customSlug) {
				if (existing) {
					const expectedSlug = `custom-${customSlug}`;
					if (existing.provider_slug !== expectedSlug || existing.base_url !== baseUrl) {
						throw new Error("custom_provider_reprovision_required");
					}
					providerSlug = existing.provider_slug;
					customProviderId = existing.custom_provider_id;
					transport = "gateway-custom";
				} else {
					operationId = await beginProviderOperation(env, "create", id, "provision_external");
					await updateProviderOperation(env, operationId, { step: "provision_external", state: "IN_PROGRESS" });
					const provisioned = await createCloudflareCustomProvider(env, { name: displayName, slug: customSlug, baseUrl: baseUrl! });
					providerSlug = `custom-${provisioned.slug}`;
					customProviderId = provisioned.id;
					provisionedExternalId = provisioned.id;
					transport = "gateway-custom";
					await updateProviderOperation(env, operationId, {
						step: "persist_provider", state: "IN_PROGRESS", externalCustomProviderId: provisioned.id,
					});
				}
			} else if (requestedAuth === "cloudflare-unified") {
				transport = "cloudflare-rest";
			}

			const credentialRequired = requestedAuth === "byok";
			let provider: ProviderRow | null;
			try {
				provider = existing
					? await updateProviderMetadata(env, id, {
						display_name: displayName, provider_slug: providerSlug, transport, auth_type: requestedAuth, base_url: baseUrl, api_path: apiPath,
						credential_required: credentialRequired ? 1 : 0, test_model: stringField(body, "testModel") || template.testModel || existing.test_model,
					})
					: await createProvider(env, {
						id, displayName, kind: template.id, providerSlug, transport, authType: requestedAuth, baseUrl, apiPath,
						credentialRequired, customProviderId, testModel: stringField(body, "testModel") || template.testModel || null, enabled: body.enabled === true,
					});
			} catch (persistError) {
				if (operationId && provisionedExternalId) {
					await updateProviderOperation(env, operationId, { step: "deprovision_external", state: "COMPENSATING", error: persistError });
					try {
						await deleteCloudflareCustomProvider(env, provisionedExternalId);
						await updateProviderOperation(env, operationId, { step: "rolled_back", state: "FAILED", error: persistError });
					} catch (compensationError) {
						await updateProviderOperation(env, operationId, {
							step: "external_cleanup_required", state: "RECONCILIATION_REQUIRED",
							externalCustomProviderId: provisionedExternalId, error: compensationError,
						});
					}
				}
				throw persistError;
			}
			if (!provider) throw new Error("provider_create_failed");

			const modelId = stringField(body, "modelId");
			if (modelId && !(await getModel(env, modelId))) {
				await createModel(env, { id: modelId, providerId: id, enabled: true, freeTier: body.freeTier === true });
			}

			let credential: unknown = null;
			const token = stringField(body, "token");
			if (requestedAuth === "byok" && token) {
				const alias = stringField(body, "tokenAlias") || "default";
				credential = await setProviderCredential(env, provider.provider_slug, alias, token);
				if (!(credential as { ok?: boolean }).ok) {
					if (operationId) await updateProviderOperation(env, operationId, { step: "credential_link", state: "RECONCILIATION_REQUIRED", error: "credential_link_failed" });
					await logAudit(env, "provider.credential.failed", id, "Cloudflare BYOK linkage failed");
					return json({ ok: false, error: "credential_link_failed", provider, credential }, 502);
				}
				await setProviderAlias(env, id, alias);
				provider = (await getProvider(env, id)) || provider;
			}
			if (operationId) await updateProviderOperation(env, operationId, { step: "complete", state: "SUCCEEDED" });
			await logAudit(env, existing ? "provider.configure" : "provider.create", id, `auth=${requestedAuth};transport=${transport}`);
			return json({ ok: true, provider: { ...provider, ...providerRuntimeReadiness(provider, env) }, credential }, existing ? 200 : 201);
		} catch (err) {
			const message = err instanceof Error ? err.message : String(err);
			return json({ ok: false, error: "provider_create_failed", detail: message }, message === "custom_provider_reprovision_required" ? 409 : 400);
		}
	}

	if (path === "/admin/api/providers" && request.method === "GET") {
		const [providers, models, rules] = await Promise.all([
			listProviders(env),
			listModels(env),
			listRoutingRules(env),
		]);
		const operations = await latestProviderOperations(env, providers.map((provider) => provider.id));
		return json({
			providers: providers.map((provider) => {
				const providerModels = models.filter((m) => m.provider_id === provider.id);
				const modelIds = new Set(providerModels.map((m) => m.id));
				return {
					...provider,
					model_count: providerModels.length,
					enabled_model_count: providerModels.filter((m) => m.enabled === 1).length,
					routing_aliases: rules.filter((r) => modelIds.has(r.model_id)).map((r) => r.public_alias).sort(),
					health_freshness: providerHealthFreshness(provider),
					...providerRuntimeReadiness(provider, env),
					latest_operation: operations.get(provider.id) ?? null,
				};
			}),
		});
	}

	if (path === "/admin/api/models" && request.method === "GET") {
		const [providers, models, rules] = await Promise.all([
			listProviders(env),
			listModels(env),
			listRoutingRules(env),
		]);
		const providersById = new Map(providers.map((p) => [p.id, p]));
		return json({
			models: models.map((model) => {
				const provider = providersById.get(model.provider_id);
				return {
					...model,
					provider_enabled: provider?.enabled ?? 0,
					provider_callable: provider ? providerCallability(provider, model, env).callable : false,
					available: model.enabled === 1 && (provider ? providerCallability(provider, model, env).callable : false),
					routing_aliases: aliasesForModel(rules, model.id),
				};
			}),
		});
	}

	if (path === "/admin/api/routing" && request.method === "GET") {
		const [providers, models, rules] = await Promise.all([
			listProviders(env),
			listModels(env),
			listRoutingRules(env),
		]);
		const providersById = new Map(providers.map((p) => [p.id, p]));
		const modelsById = new Map(models.map((m) => [m.id, m]));
		return json({
			rules: rules.map((rule) => {
				const model = modelsById.get(rule.model_id);
				const provider = model ? providersById.get(model.provider_id) : undefined;
				const readiness = model && provider ? providerCallability(provider, model, env) : null;
				const state = !model || !provider
					? "BROKEN"
					: readiness?.callable
						? "ACTIVE"
						: readiness?.reasons.includes("model_disabled")
							? "MODEL_DISABLED"
							: readiness?.reasons.includes("provider_disabled")
								? "PROVIDER_DISABLED"
								: "UNAVAILABLE";
				return {
					...rule,
					provider_id: model?.provider_id ?? null,
					model_enabled: model?.enabled ?? null,
					provider_enabled: provider?.enabled ?? null,
					state,
					callable: readiness?.callable ?? false,
					reasons: readiness?.reasons ?? ["broken_reference"],
				};
			}),
		});
	}

	if (path === "/admin/api/health" && request.method === "GET") {
		return json({ checks: await listRecentHealthChecks(env) });
	}

	if (path === "/admin/api/usage" && request.method === "GET") {
		return json(await getAdminUsageSummary(env, toolCatalog.length));
	}

	if (path === "/admin/api/tools" && request.method === "GET") {
		const catalog = toolCatalog.map((tool) => ({
			name: tool.name,
			description: tool.description,
			inputSchema: tool.inputSchema,
			annotations: {
				readOnlyHint: tool.annotations?.readOnlyHint === true,
				destructiveHint: tool.annotations?.destructiveHint === true,
				idempotentHint: tool.annotations?.idempotentHint === true,
				openWorldHint: tool.annotations?.openWorldHint === true,
			},
		}));
		return json({
			count: catalog.length,
			readOnlyCount: catalog.filter((tool) => tool.annotations.readOnlyHint).length,
			destructiveCount: catalog.filter((tool) => tool.annotations.destructiveHint).length,
			openWorldCount: catalog.filter((tool) => tool.annotations.openWorldHint).length,
			tools: catalog,
		});
	}

	if (path === "/admin/api/settings" && request.method === "GET") {
		return json(getAdminSettingsSummary(env));
	}

	if (path === "/admin/api/models" && request.method === "POST") {
		const body = await readJsonObject(request);
		if (!body) return json({ ok: false, error: "invalid_json" }, 400);
		const id = stringField(body, "id");
		const providerId = stringField(body, "providerId");
		if (!id || !providerId) return json({ ok: false, error: "id_and_providerId_required" }, 400);
		try {
			const model = await createModel(env, { id, providerId, enabled: body.enabled !== false, freeTier: body.freeTier === true });
			await logAudit(env, "model.create", id, `provider=${providerId}`);
			return json({ ok: true, model }, 201);
		} catch (err) {
			const detail = err instanceof Error ? err.message : String(err);
			return json({ ok: false, error: detail }, detail === "provider_not_found" ? 404 : 409);
		}
	}

	const modelMatch = path.match(/^\/admin\/api\/models\/([^/]+)$/);
	if (modelMatch && request.method === "PATCH") {
		const id = decodeURIComponent(modelMatch[1]);
		const body = await readJsonObject(request);
		if (!body) return json({ ok: false, error: "invalid_json" }, 400);
		if (typeof body.enabled !== "boolean") return json({ ok: false, error: "enabled_must_be_boolean" }, 400);

		const existing = await getModel(env, id);
		if (!existing) return json({ ok: false, error: "model_not_found" }, 404);
		const rules = await listRoutingRules(env);
		const affectedAliases = aliasesForModel(rules, id);

		try {
			const updated = await setModelEnabled(env, id, body.enabled);
			if (!updated) return json({ ok: false, error: "model_not_found" }, 404);
			const provider = await getProvider(env, updated.provider_id);
			await logAudit(
				env,
				body.enabled ? "model.enable" : "model.disable",
				id,
				`aliases=${affectedAliases.join(",") || "none"}`,
			);
			return json({
				ok: true,
				model: {
					...updated,
					provider_enabled: provider?.enabled ?? 0,
					provider_callable: provider ? providerCallability(provider, updated, env).callable : false,
					available: provider ? providerCallability(provider, updated, env).callable : false,
					routing_aliases: affectedAliases,
				},
				affectedAliases,
			});
		} catch {
			return json({ ok: false, error: "model_update_failed" }, 500);
		}
	}

	const priorityMatch = path.match(/^\/admin\/api\/providers\/([^/]+)\/priority$/);
	if (priorityMatch && request.method === "POST") {
		const id = decodeURIComponent(priorityMatch[1]);
		const body = await readJsonObject(request);
		if (!body || (body.direction !== "up" && body.direction !== "down")) return json({ ok: false, error: "direction_must_be_up_or_down" }, 400);
		try {
			const providers = await moveProviderPriority(env, id, body.direction);
			await logAudit(env, "provider.priority", id, `direction=${body.direction}`);
			return json({ ok: true, providers: providers.map((provider) => ({ id: provider.id, priority: provider.priority })) });
		} catch (err) {
			const detail = err instanceof Error ? err.message : String(err);
			return json({ ok: false, error: detail }, detail === "provider_not_found" ? 404 : 500);
		}
	}

	const providerMatch = path.match(/^\/admin\/api\/providers\/([^/]+)(\/(health-test|credential))?$/);
	if (providerMatch) {
		const id = decodeURIComponent(providerMatch[1]);
		const action = providerMatch[3];

		if (!action && request.method === "DELETE") {
			const provider = await getProvider(env, id);
			if (!provider) return json({ ok: false, error: "provider_not_found" }, 404);
			const force = url.searchParams.get("force") === "true";
			const [models, rules] = await Promise.all([listModels(env), listRoutingRules(env)]);
			const providerModels = models.filter((model) => model.provider_id === id);
			const modelIds = new Set(providerModels.map((model) => model.id));
			const dependentRules = rules.filter((rule) => modelIds.has(rule.model_id));
			if (!force && (providerModels.length > 0 || dependentRules.length > 0)) {
				return json({
					ok: false, error: "provider_has_dependencies", models: providerModels.map((model) => model.id),
					routingAliases: dependentRules.map((rule) => rule.public_alias),
				}, 409);
			}

			const operationId = await beginProviderOperation(env, "delete", id, "disable_provider", provider.custom_provider_id);
			try {
				await updateProviderOperation(env, operationId, { step: "disable_provider", state: "IN_PROGRESS" });
				await setProviderEnabled(env, id, false);

				if (provider.auth_type === "byok" && provider.byok_alias) {
					await updateProviderOperation(env, operationId, { step: "delete_credential", state: "IN_PROGRESS" });
					const credential = await deleteProviderCredential(env, provider.provider_slug, provider.byok_alias);
					if (!credential.ok) {
						await updateProviderOperation(env, operationId, { step: "credential_cleanup_required", state: "RECONCILIATION_REQUIRED", error: credential.error || "credential_delete_failed" });
						return json({ ok: false, error: "provider_delete_requires_reconciliation", stage: "credential" }, 502);
					}
					await setProviderAlias(env, id, null);
				}

				if (provider.custom_provider_id) {
					await updateProviderOperation(env, operationId, { step: "deprovision_external", state: "IN_PROGRESS" });
					try {
						await deleteCloudflareCustomProvider(env, provider.custom_provider_id);
					} catch (error) {
						await updateProviderOperation(env, operationId, { step: "external_cleanup_required", state: "RECONCILIATION_REQUIRED", error });
						return json({ ok: false, error: "provider_delete_requires_reconciliation", stage: "custom_provider" }, 502);
					}
				}

				await updateProviderOperation(env, operationId, { step: "delete_local_state", state: "IN_PROGRESS" });
				const deleted = await deleteProviderLocalState(env, id, true);
				await updateProviderOperation(env, operationId, { step: "complete", state: "SUCCEEDED" });
				await logAudit(env, "provider.delete", id, `models=${deleted.modelCount};routing_rules=${deleted.routingRuleCount}`);
				return json({ ok: true, ...deleted });
			} catch (error) {
				await updateProviderOperation(env, operationId, { step: "local_cleanup_required", state: "RECONCILIATION_REQUIRED", error }).catch(() => undefined);
				return json({ ok: false, error: "provider_delete_failed" }, 500);
			}
		}

		if (!action && request.method === "PATCH") {
			const body = await readJsonObject(request);
			if (!body) return json({ ok: false, error: "invalid_json" }, 400);
			if (typeof body.enabled !== "boolean") return json({ ok: false, error: "enabled_must_be_boolean" }, 400);

			const existing = await getProvider(env, id);
			if (!existing) return json({ ok: false, error: "provider_not_found" }, 404);
			const [models, rules] = await Promise.all([listModels(env), listRoutingRules(env)]);
			const providerModels = models.filter((m) => m.provider_id === id);
			const modelIds = new Set(providerModels.map((m) => m.id));
			const affectedAliases = rules.filter((r) => modelIds.has(r.model_id)).map((r) => r.public_alias).sort();

			try {
				const updated = await setProviderEnabled(env, id, body.enabled);
				if (!updated) return json({ ok: false, error: "provider_not_found" }, 404);
				await logAudit(
					env,
					body.enabled ? "provider.enable" : "provider.disable",
					id,
					`models=${providerModels.length};aliases=${affectedAliases.join(",") || "none"}`,
				);
				return json({
					ok: true,
					provider: updated,
					affectedModels: providerModels.map((m) => m.id),
					affectedAliases,
				});
			} catch {
				return json({ ok: false, error: "provider_update_failed" }, 500);
			}
		}

		if (action === "health-test" && request.method === "POST") {
			const rate = await consumeRateLimit(env.DM_DB, { principal: "admin-owner", bucket: `admin:health-test:${id}`, limit: 30, windowSeconds: 60 }).catch(() => null);
			if (!rate) return json({ ok: false, error: "rate_limit_state_unavailable" }, 503);
			if (!rate.allowed) return json({ ok: false, error: "rate_limited", retryAfterSeconds: rate.retryAfterSeconds }, 429);
			const provider = await getProvider(env, id);
			if (!provider) return json({ ok: false, error: "provider_not_found" }, 404);
			const result = await testProviderConnection(env, provider);
			await recordHealthResult(env, id, result.state, result.latencyMs, result.errorMessage, {
				httpStatus: result.httpStatus, gatewayLogId: result.gatewayLogId, gatewayStep: result.gatewayStep, cfRay: result.cfRay, modelId: result.modelId, correlationId: result.correlationId,
			});
			await logAudit(env, "provider.health-test", id, `state=${result.state};gateway=${result.gatewayVerified ? "verified" : "unverified"};correlation=${result.correlationId}`);
			return json({ ok: true, ...result });
		}

		if (action === "credential" && request.method === "POST") {
			const provider = await getProvider(env, id);
			if (!provider) return json({ ok: false, error: "provider_not_found" }, 404);
			if (provider.auth_type !== "byok") return json({ ok: false, error: "provider_auth_type_is_not_byok" }, 409);
			const body = await readJsonObject(request);
			if (!body) return json({ ok: false, error: "invalid_json" }, 400);
			if (typeof body.value !== "string" || !body.value.trim()) return json({ ok: false, error: "value_required" }, 400);
			const alias = typeof body.alias === "string" && body.alias.trim() ? body.alias.trim() : "default";
			const operationId = await beginProviderOperation(env, "credential_set", id, "set_secret");
			await updateProviderOperation(env, operationId, { step: "set_secret", state: "IN_PROGRESS" });
			const result = await setProviderCredential(env, provider.provider_slug, alias, body.value.trim());
			if (result.ok) {
				await setProviderAlias(env, id, alias);
				await logAudit(env, "provider.credential.set", id, `secret_id=${result.secretId}`);

				// Post-config verification is real and must produce Cloudflare Gateway evidence to become HEALTHY.
				const refreshed = (await getProvider(env, id)) || provider;
				const health = await testProviderConnection(env, refreshed);
				await recordHealthResult(env, id, health.state, health.latencyMs, health.errorMessage, {
					httpStatus: health.httpStatus, gatewayLogId: health.gatewayLogId, gatewayStep: health.gatewayStep, cfRay: health.cfRay, modelId: health.modelId, correlationId: health.correlationId,
				});
				await updateProviderOperation(env, operationId, { step: "complete", state: "SUCCEEDED" });
				await logAudit(env, "provider.health-test", id, `state=${health.state};gateway=${health.gatewayVerified ? "verified" : "unverified"};correlation=${health.correlationId}`);

				return json({ ...result, healthState: health.state, gatewayVerified: health.gatewayVerified === true }, 200);
			}
			await updateProviderOperation(env, operationId, { step: "credential_reconciliation_required", state: "RECONCILIATION_REQUIRED", error: result.error || "credential_set_failed" });
			await recordHealthResult(env, id, "NOT_CONFIGURED", null, result.error || "Credential set failed");
			return json(result, 502);
		}

		if (action === "credential" && request.method === "DELETE") {
			const provider = await getProvider(env, id);
			if (!provider) return json({ ok: false, error: "provider_not_found" }, 404);
			if (provider.auth_type !== "byok") return json({ ok: false, error: "provider_auth_type_is_not_byok" }, 409);
			const operationId = await beginProviderOperation(env, "credential_delete", id, "delete_provider_config");
			await updateProviderOperation(env, operationId, { step: "delete_provider_config", state: "IN_PROGRESS" });
			const result = await deleteProviderCredential(env, provider.provider_slug, provider.byok_alias || "default");
			if (result.ok) {
				await setProviderAlias(env, id, null);
				await updateProviderOperation(env, operationId, { step: "complete", state: "SUCCEEDED" });
				await logAudit(env, "provider.credential.delete", id, null);
				await recordHealthResult(env, id, "REVOKED", null, null);
			} else {
				await updateProviderOperation(env, operationId, { step: "credential_cleanup_required", state: "RECONCILIATION_REQUIRED", error: result.error || "credential_delete_failed" });
			}
			return json(result, result.ok ? 200 : 502);
		}

	}

	if (path === "/admin/api/logs" && request.method === "GET") {
		const q = url.searchParams;
		if (q.has("search") || q.has("action") || q.has("actor") || q.has("target") || q.has("limit")) {
			const limit = Math.min(200, Math.max(1, Number(q.get("limit")) || 50));
			return json(await queryAuditEvents(env, {
				search: q.get("search") || undefined,
				actionPrefix: q.get("action") || undefined,
				actor: q.get("actor") || undefined,
				target: q.get("target") || undefined,
				limit,
			}));
		}
		return json({ events: await recentAudit(env) });
	}

	return json({ ok: false, error: "not_found" }, 404);
}
