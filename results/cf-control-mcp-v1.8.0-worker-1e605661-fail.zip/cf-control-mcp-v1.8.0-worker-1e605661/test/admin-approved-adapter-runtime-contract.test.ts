import test from "node:test";
import assert from "node:assert/strict";
import { adapterScript } from "../src/admin/ui/approved/adapter";

const fakeReferenceMarkers = [
  "admin@dreamworker.ai",
  "44 tools",
  "10 sampled tools shown",
  "7 registered",
  "3 active",
  "Preview running",
  "Simulation completed",
];

test("approved runtime adapters bind to the authoritative Admin API schema", () => {
  const providers = adapterScript("providers");
  const models = adapterScript("models");
  const usage = adapterScript("usage");

  assert.ok(providers.includes("p.byok_alias"), "Providers must use the real byok_alias field");
  assert.ok(models.includes("m.provider_enabled"), "Models must preserve provider gating separately from model.enabled");
  assert.ok(usage.includes("activity.totalAuditEvents"));
  assert.ok(usage.includes("registry.enabledModels"));
  assert.ok(usage.includes("registry.toolCatalogCount"));
  assert.ok(usage.includes("health.totalChecks"));
  assert.ok(usage.includes("coverage.gatewayRequests"));
  assert.ok(usage.includes("coverage.tokens"));
  assert.ok(usage.includes("coverage.cost"));
});

test("approved runtime adapters fail closed instead of carrying reference operational samples", () => {
  for (const page of ["overview", "providers", "models", "tools", "routing", "health", "usage"]) {
    const script = adapterScript(page);
    for (const marker of fakeReferenceMarkers) {
      assert.ok(!script.includes(marker), `${page} adapter must not hardcode reference marker: ${marker}`);
    }
  }

  const tools = adapterScript("tools");
  assert.ok(tools.includes("list.innerHTML = ''"));
  assert.ok(tools.includes("Full catalog: loading authenticated /admin/api/tools"));
  assert.ok(tools.includes("Unavailable in Admin"));
  assert.ok(!tools.includes("/admin/api/tools/call"));
});

test("live loading and command surfaces cannot report preview-only completion", () => {
  const loading = adapterScript("loading");
  assert.ok(loading.includes("/admin/api/prelogin"), "loading must read the real signed-session state before Login");
  assert.ok(loading.includes("/admin/login?ready=1"), "loading must verify and hand off to the real Login document");
  assert.ok(loading.includes("minimumPreloginVisibleMs = 900"), "pre-login Loading should remain visibly perceivable after real checks settle");
  assert.ok(loading.includes("owner-token sign-in contract verified"));
  for (const endpoint of [
    "/admin/api/overview",
    "/admin/api/providers",
    "/admin/api/models",
    "/admin/api/tools",
    "/admin/api/routing",
    "/admin/api/health",
    "/admin/api/usage",
    "/admin/api/logs",
    "/admin/api/settings",
  ]) assert.ok(loading.includes(endpoint), `loading must probe ${endpoint}`);
  assert.ok(!loading.includes("setInterval("));

  const overview = adapterScript("overview");
  const usage = adapterScript("usage");
  assert.ok(overview.includes("navigation-only until those actions have real API routes"));
  assert.ok(usage.includes("Execution unavailable"));
});
