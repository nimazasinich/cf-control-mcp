# Final Verification Report

Date: 2026-09-08
Project: cf-control-mcp
Package version: 1.8.0
Final status: BLOCKED

## Summary

The local production gate is PASS and was not repeated after the final deployment except where source changed before deployment. The Worker deployed successfully from the verified source tree after process-only credential mapping into the current PowerShell environment. No token, secret, or env-file value was printed, logged, rotated, revoked, replaced, committed, or copied into source.

Production deployment is PASS. Production acceptance is BLOCKED only because the local verification environment does not contain the separate Provider Gateway client credential `GATEWAY_AUTH_TOKEN`. The live Worker does have a `GATEWAY_AUTH_TOKEN` secret binding name, but Cloudflare does not reveal secret values and this pass did not change or rebook it.

Do not call this release `production-verified` until the blocked `/v1` client acceptance gates pass against the exact deployed source.

## Deployment Identity

- Worker name: `cf-control-mcp`
- Worker URL: `https://cf-control-mcp.amin-chinisaz-edu.workers.dev`
- Worker Version ID: `1e605661-67ea-467e-ac1e-1d3242ba4c59`
- Version creation time: `2026-09-08T04:55:04.954Z`
- Deployment command: `npx wrangler deploy`
- Deployment result: PASS
- Upload size: 2444.24 KiB / gzip 1101.34 KiB
- Worker startup time: 16 ms
- Bindings reported by Wrangler:
  - D1 `DM_DB` -> `DM_DB` (`138a2aef-9f5a-4635-8346-dc474fdfff93`)
  - Workers AI binding `AI`
  - Var `CF_AIG_GATEWAY_SLUG=cf-control-mcp`

## Source Identity

- Git/source SHA: UNVERIFIED
  - Reason: this checkout has no `.git` metadata.
- CI run ID: UNVERIFIED
  - Reason: no repository/remote CI context is available in this checkout.
- Package version: PASS, `1.8.0`
- Version sync: PASS, `package.json` and README badge both report `1.8.0`.

## Local Gate Evidence

- npm clean install: PASS
  - Command: `npm ci --cache .\.npm-cache --prefer-online`
  - Result: added 140 packages, audited 141 packages.
  - Audit note: 9 vulnerabilities reported by npm; no `npm audit fix --force` was run.
- TypeScript: PASS
  - Command: `npm run typecheck`
  - Result: `tsc --noEmit` completed successfully.
- Full test suite after source changes: PASS
  - Command: `npm test`
  - Result: 238 total / 230 PASS / 8 SKIP / 0 FAIL / 0 TODO
  - Duration: 6499.1878 ms
- Local migration verification: PASS
  - Command: `python scripts/verify_migrations_local.py`
  - Result: fresh schema + 0002->0008 upgrade chain passed.
- Version sync: PASS
  - Command: `node scripts/check-version-sync.mjs`
  - Result: package and README badge both report `1.8.0`.
- Wrangler bundle dry-run: PASS
  - Command: `npx wrangler deploy --dry-run`
  - Result: bundle generated successfully with expected bindings.

## Skipped Local Tests

The 8 skipped tests are intentional HTML/parser cases:

- `htmlToText extracts title and drops script/style`
- `htmlToText enforces a UTF-8 byte cap (not char count)`
- `htmlToMarkdown preserves headings, lists and blockquotes`
- `htmlToMarkdown handles nested blocks without clobbering text`
- `extractLinks resolves relative URLs and dedupes`
- `extractLinks sameOriginOnly filters foreign origins`
- `extractBySelectors returns per-selector matched text`
- `extractBySelectors handles nested matches of the same selector`

## Credential Role Matrix

- `CLOUDFLARE_API_TOKEN`: VALID for Wrangler auth, Worker deployment, D1 readback, Worker secret-name listing, AI Gateway metadata, BYOK Secrets Store, and BYOK provider config.
- `CLOUDFLARE_ACCOUNT_ID`: VALID for account `324f9984b34bf5d39a778c9753c49632`.
- `CF_AIG_TOKEN`: VALID for direct AI Gateway authentication; the optional direct probe reached upstream and returned explicit Gemini quota exhaustion HTTP 429.
- `MCP_AUTH_TOKEN`: VALID for `/mcp` bearer auth and `/admin` owner login.
- `GATEWAY_AUTH_TOKEN`: PRESENT as a live Worker secret binding name; MISSING from the local verification environment, so `/v1` client gates are BLOCKED.
- Hugging Face token candidate: VALID by API status.
- GitHub token candidate: VALID by API status.
- Vercel token candidate: VALID by API status.

## Production Acceptance Matrix

- MCP initialize and tools/list: PASS
  - Live `/mcp` JSON-RPC initialized successfully and returned the tool catalog.
- MCP D1-backed execution tools: PASS
  - `exec_tools_live_smoke.py` passed `list_code_runtimes`, `gh_run_code`, `gh_get_run_result`, `run_code` success, non-zero exit, and invalid-language fail-closed behavior.
- Admin login/prelogin/security behavior: PASS
  - Unauthenticated `/admin/api/prelogin`: HTTP 200 `authenticated=false`.
  - Owner `/admin/login`: HTTP 200, signed session issued.
  - Authenticated `/admin/api/prelogin`: HTTP 200 `authenticated=true`.
  - Cross-origin admin mutation with valid session: HTTP 403 rejected.
- `/v1` invalid-token challenge: PASS
  - Production verifier observed HTTP 401 `invalid_api_key`.
- `/v1/models`: BLOCKED
  - Reason: local `GATEWAY_AUTH_TOKEN` is missing.
- Workers AI token-free request through `/v1`: BLOCKED
  - Reason: local `GATEWAY_AUTH_TOKEN` is missing.
- Available native/custom provider Gateway round-trip: BLOCKED
  - Reason: local `GATEWAY_AUTH_TOKEN` is missing.
- Explicit-model no-substitution: BLOCKED
  - Reason: local `GATEWAY_AUTH_TOKEN` is missing.
- OAuth scope enforcement: PASS
  - `oauth_smoke.py` passed discovery, DCR, read-scope tool filtering, admin denial, PKCE, token exchange, MCP initialize, refresh, legacy path, and 401 challenge.
- Health/audit/correlation evidence: PASS
  - D1 readback shows `audit_events=75`, `health_checks=4`, and live admin/security probes added audit activity without exposing secrets.
- Worker required secret bindings: PASS
  - Worker secret names include required bindings; missing list was empty.
- D1 registry and migration integrity: PASS
  - `npx wrangler d1 migrations list DM_DB --remote`: `No migrations to apply!`
  - Applied remote migration level: `0002_update_gemini_models_v18.sql` through `0008_rate_limits.sql`.
  - Remote tables: `_cf_KV`, `audit_events`, `d1_migrations`, `health_checks`, `models`, `oauth_codes`, `provider_operations`, `providers`, `rate_limit_buckets`, `refresh_token_families`, `routing_rules`, `sqlite_sequence`.
  - Remote counts: `providers=17`, `models=10`, `routing_rules=5`, `audit_events=75`, `health_checks=4`, `rate_limit_buckets=4`.
  - Routing invariants: PASS, `fast -> gemini-3.6-flash`, `coding -> gemini-3.8-flash`, `research -> gemini-3.8-flash`, `free/auto -> @cf/zai-org/glm-4.7-flash`.

## Artifact Security

- Release packaging excludes `.env`, `.env.*`, `.npm-cache`, `node_modules`, nested ZIPs, `SHA256SUMS.txt`, and `fix-cf-aig-token.bat`.
- ZIP SHA-256 is recorded externally after final packaging to avoid self-referential checksum drift inside the package.

## Source Changes In This Pass

- `scripts/package_checkpoint.py`: excludes `.env`, `.env.*`, `.npm-cache`, `fix-cf-aig-token.bat`, dependency folders, and nested ZIP artifacts.
- `scripts/oauth_smoke.py`: aligns live OAuth smoke with read-scope filtering and verifies admin denial instead of expecting privileged tools under read-only OAuth scope.
- `FINAL_VERIFICATION_REPORT.md`: updated with final deployment identity and current production acceptance evidence.

## Final Status

Local release gate: PASS
Deploy dry-run: PASS
Production deployment: PASS
Production acceptance: BLOCKED

The release is deployed but must not be called production-verified until the blocked `/v1` client gates pass against Worker Version ID `1e605661-67ea-467e-ac1e-1d3242ba4c59` or a newer explicitly verified deployment.
